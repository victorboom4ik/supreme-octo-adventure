#!/system/bin/sh
# Local, foreground launcher. No license server or installation-time autorun.
set -eu
SOURCE_DIR=${1:?missing source directory}
USER_ID=${2:-0}
case "$USER_ID" in ''|*[!0-9]*) echo 'Invalid Android user'; exit 2;; esac
GAME_PACKAGE=com.axlebolt.standoff2
REPORTED_GAME_DIR=${3:-}
GAME_UID=${4:-}
GAME_COMPONENT=${5:?missing game launcher activity}
case "$GAME_COMPONENT" in com.axlebolt.standoff2/*) ;; *) echo 'Invalid game activity'; exit 2;; esac
case "$REPORTED_GAME_DIR" in ''|/*) ;; *) echo 'Invalid game directory'; exit 2;; esac
case "$GAME_UID" in ''|*[!0-9]*) echo 'Missing game UID from Android'; exit 2;; esac
GAME_DIR=
BIN_DIR=/data/local/tmp/zenin_komarq_$USER_ID
CFG_DIR=/storage/emulated/$USER_ID/Zenin/cfg
LOCK_DIR=$BIN_DIR/launch.lock

fail() { echo "Ошибка: $*"; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Root required'
ROOT_NAMESPACE=$(readlink "/proc/$$/ns/mnt" 2>/dev/null || true)
INIT_NAMESPACE=$(readlink /proc/1/ns/mnt 2>/dev/null || true)
echo "Пространство монтирования root: $ROOT_NAMESPACE; init: $INIT_NAMESPACE"
# PackageManager supplies the game's actual dataDir and UID. Android devices
# and secondary profiles need not expose the guessed /data/user path to su.
select_game_dir() {
    [ -n "$1" ] && [ -d "$1" ] || return 1
    DIR_UID=$(stat -c %u "$1" 2>/dev/null || true)
    if [ "$DIR_UID" != "$GAME_UID" ]; then
        echo "Каталог $1 виден, но UID владельца $DIR_UID не совпадает с UID игры $GAME_UID."
        return 1
    fi
    GAME_DIR=$1
    return 0
}
if ! select_game_dir "$REPORTED_GAME_DIR"; then
    if ! select_game_dir "/data/user/$USER_ID/$GAME_PACKAGE"; then
        if [ "$USER_ID" = 0 ]; then select_game_dir "/data/data/$GAME_PACKAGE" || true; fi
    fi
fi
if [ -z "$GAME_DIR" ]; then
    echo "Android сообщил каталог: $REPORTED_GAME_DIR"
    echo "Проверен путь: /data/user/$USER_ID/$GAME_PACKAGE"
    if [ "$USER_ID" = 0 ]; then echo "Проверен путь: /data/data/$GAME_PACKAGE"; fi
    echo 'Диагностика root и доступа к каталогу:'
    id
    id -Z 2>/dev/null || true
    ls -ldn "$REPORTED_GAME_DIR" "/data/user/$USER_ID/$GAME_PACKAGE" 2>&1 || true
    if [ "$USER_ID" = 0 ]; then ls -ldn "/data/data/$GAME_PACKAGE" 2>&1 || true; fi
    if [ -n "$ROOT_NAMESPACE" ] && [ -n "$INIT_NAMESPACE" ] && [ "$ROOT_NAMESPACE" != "$INIT_NAMESPACE" ]; then
        echo 'Выбранная root-команда не перевела shell в глобальное пространство монтирования.'
    fi
    fail 'Каталог игры недоступен в выбранном root-пространстве. Пришлите журнал диагностики выше.'
fi
TARGET_DIR=$GAME_DIR/files/.zenin_komarq
echo "Используется каталог игры: $GAME_DIR (UID $GAME_UID)"
mkdir -p "$BIN_DIR"
chmod 700 "$BIN_DIR"
if [ "${6:-}" != guarded ]; then
    cp "$SOURCE_DIR/zenin_android_tools" "$BIN_DIR/zenin_android_tools.$$.new"
    chmod 700 "$BIN_DIR/zenin_android_tools.$$.new"
    mv -f "$BIN_DIR/zenin_android_tools.$$.new" "$BIN_DIR/zenin_android_tools"
    exec "$BIN_DIR/zenin_android_tools" guard "$BIN_DIR/launch.flock" /system/bin/sh \
        "$SOURCE_DIR/launch.sh" "$SOURCE_DIR" "$USER_ID" "$REPORTED_GAME_DIR" "$GAME_UID" "$GAME_COMPONENT" guarded
fi
if [ -d "$LOCK_DIR" ]; then
    rm -rf "$LOCK_DIR"
    echo 'Очищена старая блокировка r7 от прерванного запуска.'
fi
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
echo 'Закрытие предыдущего процесса игры…'
/system/bin/am force-stop --user "$USER_ID" "$GAME_PACKAGE" || fail 'Не удалось остановить предыдущий процесс игры.'
CFG_PID_FILE=$BIN_DIR/configd.pid
is_our_configd() {
    OLD_EXE=$(readlink "/proc/$1/exe" 2>/dev/null || true)
    case "$OLD_EXE" in
        "$BIN_DIR/zenin_configd"|"$BIN_DIR/zenin_configd (deleted)") return 0;;
        "$BIN_DIR/zenin_android_tools"|"$BIN_DIR/zenin_android_tools (deleted)")
            tr '\000' ' ' 2>/dev/null < "/proc/$1/cmdline" | grep -q ' configd '
            return $?;;
    esac
    return 1
}
if [ -f "$CFG_PID_FILE" ]; then
    OLD_PID=$(cat "$CFG_PID_FILE")
    case "$OLD_PID" in
        ''|*[!0-9]*) ;;
        *)
            if is_our_configd "$OLD_PID"; then kill "$OLD_PID" 2>/dev/null || true; sleep 1; fi
            ;;
    esac
fi
# A previous APK may have left the daemon running without a valid pid file.
# Only stop processes executing this launcher's own daemon path.
for OLD_PID in $(pidof zenin_configd zenin_android_tools 2>/dev/null || true); do
    if is_our_configd "$OLD_PID"; then kill "$OLD_PID" 2>/dev/null || true; sleep 1; fi
done
for file in remote_dlopen_injector zenin_configd; do
    [ -f "$SOURCE_DIR/$file" ] || fail "Missing $file"
    cp "$SOURCE_DIR/$file" "$BIN_DIR/$file.new"
    chmod 700 "$BIN_DIR/$file.new"
    mv -f "$BIN_DIR/$file.new" "$BIN_DIR/$file"
done
mkdir -p "$TARGET_DIR" "$CFG_DIR/wav"
chmod 755 "$TARGET_DIR" "$CFG_DIR" "$CFG_DIR/wav"
cp "$SOURCE_DIR/libZeninInternal.so" "$TARGET_DIR/libZeninInternal.so.new"
chmod 644 "$TARGET_DIR/libZeninInternal.so.new"
chown "$GAME_UID:$GAME_UID" "$TARGET_DIR" "$TARGET_DIR/libZeninInternal.so.new"
mv -f "$TARGET_DIR/libZeninInternal.so.new" "$TARGET_DIR/libZeninInternal.so"
cp "$SOURCE_DIR/libZeninFaultLogger.so" "$TARGET_DIR/libZeninFaultLogger.so.new"
chmod 644 "$TARGET_DIR/libZeninFaultLogger.so.new"
chown "$GAME_UID:$GAME_UID" "$TARGET_DIR/libZeninFaultLogger.so.new"
mv -f "$TARGET_DIR/libZeninFaultLogger.so.new" "$TARGET_DIR/libZeninFaultLogger.so"
if command -v restorecon >/dev/null 2>&1; then restorecon -RF "$TARGET_DIR" || true; fi

echo 'Запуск нового процесса игры…'
/system/bin/am start --user "$USER_ID" -n "$GAME_COMPONENT" || fail 'Не удалось открыть игру.'
echo 'Ожидание процесса игры и Unity…'
PID=
ATTEMPT=0
while [ "$ATTEMPT" -lt 90 ]; do
    CANDIDATES=$(pidof "$GAME_PACKAGE" 2>/dev/null || true)
    for CANDIDATE in $CANDIDATES; do
        PROC_UID=$(stat -c %u "/proc/$CANDIDATE" 2>/dev/null || true)
        if [ "$PROC_UID" = "$GAME_UID" ] && grep -q '/libunity.so' "/proc/$CANDIDATE/maps"; then
            PID=$CANDIDATE
            break
        fi
    done
    [ -z "$PID" ] || break
    ATTEMPT=$((ATTEMPT + 1))
    sleep 1
done
[ -n "$PID" ] || fail 'Не удалось дождаться Unity. Откройте игру и повторите запуск.'
echo "PID игры: $PID"
GAME_CONTEXT=$(tr -d '\000\r\n' < "/proc/$PID/attr/current" 2>/dev/null || true)
[ -n "$GAME_CONTEXT" ] || GAME_CONTEXT=-
echo "SELinux-контекст игры: $GAME_CONTEXT"
echo 'Запуск Android-сервера конфигураций…'
: > "$BIN_DIR/configd.log"
"$BIN_DIR/zenin_android_tools" configd "$CFG_DIR" "$CFG_DIR/wav" "$BIN_DIR/configd.log" "$GAME_UID" "$GAME_CONTEXT" \
    > "$BIN_DIR/configd-start.log" 2>&1 < /dev/null &
CFG_PID=$!
printf '%s\n' "$CFG_PID" > "$CFG_PID_FILE"
sleep 2
if ! kill -0 "$CFG_PID" 2>/dev/null; then
    cat "$BIN_DIR/configd-start.log"
    echo 'Пробуем предоставленный сервер конфигураций…'
    "$BIN_DIR/zenin_configd" "$CFG_DIR" "$CFG_DIR/wav" "$BIN_DIR/configd-original.log" "$GAME_UID" \
        > "$BIN_DIR/configd-start.log" 2>&1 < /dev/null &
    CFG_PID=$!
    printf '%s\n' "$CFG_PID" > "$CFG_PID_FILE"
    sleep 2
fi
if ! kill -0 "$CFG_PID" 2>/dev/null; then
    echo 'Сервер конфигураций завершился. Его сообщения:'
    cat "$BIN_DIR/configd-start.log"
    cat "$BIN_DIR/configd.log"
    if [ -f "$BIN_DIR/configd-original.log" ]; then tail -n 10 "$BIN_DIR/configd-original.log"; fi
    id -Z 2>/dev/null || true
    rm -f "$CFG_PID_FILE"
    echo 'Конфиги пока недоступны; загрузка меню продолжается.'
else
    echo "Сервер конфигураций запущен: PID $CFG_PID"
    cat "$BIN_DIR/configd-start.log"
fi
if grep -q '/.zenin_komarq/libZeninInternal.so' "/proc/$PID/maps"; then
    fail 'Для запуска r8 полностью перезапустите игру: в текущем процессе библиотека уже загружена.'
fi
echo 'Unity загружена. Ожидание инициализации игры — 50 секунд…'
sleep 50
[ -r "/proc/$PID/maps" ] || fail 'Игра закрылась до загрузки библиотеки.'
echo 'Карты Unity перед инъекцией:'
grep '/libunity.so' "/proc/$PID/maps" || true
echo 'Загрузка библиотеки 1.4 без Entry…'
rm -f "$TARGET_DIR/native-fault-r5.txt"
set +e
"$BIN_DIR/remote_dlopen_injector" "$PID" "$TARGET_DIR/libZeninInternal.so" - > "$BIN_DIR/preload.log" 2>&1
RESULT=$?
set -e
cat "$BIN_DIR/preload.log"
[ "$RESULT" = 0 ] || fail "Preload exited with $RESULT"
echo 'Установка записи SIGSEGV после конструкторов…'
set +e
"$BIN_DIR/remote_dlopen_injector" "$PID" "$TARGET_DIR/libZeninFaultLogger.so" InstallCrashLogger > "$BIN_DIR/fault-logger.log" 2>&1
RESULT=$?
set -e
cat "$BIN_DIR/fault-logger.log"
[ "$RESULT" = 0 ] || fail "Fault logger injector exited with $RESULT"
grep -q 'entry_result=0x1' "$BIN_DIR/fault-logger.log" || fail 'Fault logger initialization failed'
[ -f "$TARGET_DIR/native-fault-r5.txt" ] || fail 'Fault logger did not create its report file'
grep -q '^LOGGER_INSTALLED$' "$TARGET_DIR/native-fault-r5.txt" || fail 'Fault logger did not finish writing its installation record'
echo 'Карты библиотек перед Entry:'
grep -E '/\.zenin_komarq/libZenin|/libc\.so|/linker64' "/proc/$PID/maps" || true
echo 'Вызов Entry библиотеки 1.4…'
set +e
"$BIN_DIR/remote_dlopen_injector" "$PID" "$TARGET_DIR/libZeninInternal.so" @0xe7ded0 \
    > "$BIN_DIR/injector.log" 2>&1
RESULT=$?
set -e
cat "$BIN_DIR/injector.log"
[ "$RESULT" = 0 ] || fail "Injector exited with $RESULT"
grep -q 'entry_result=0x1' "$BIN_DIR/injector.log" || fail 'Entry did not report success'
echo 'Библиотека загружена, поток Entry запущен.'
echo 'Карты загруженной библиотеки:'
grep '/.zenin_komarq/libZenin' "/proc/$PID/maps" || true
echo 'Наблюдение за процессом игры — 30 секунд…'
OBSERVE=0
MENU_READY=0
MENU_PROBE_OK=0
MODULE_BASE=$(sed -n 's/.*module_base=\(0x[0-9a-fA-F]*\).*/\1/p' "$BIN_DIR/injector.log" | head -n 1)
while [ "$OBSERVE" -lt 30 ]; do
    if [ ! -d "/proc/$PID" ] || [ "$(stat -c %u "/proc/$PID" 2>/dev/null || true)" != "$GAME_UID" ]; then
        echo 'Игра закрылась после Entry. Будет собран native crash, если Android его записал.'
        exit 10
    fi
    if [ "$MENU_READY" = 0 ] && [ -n "$MODULE_BASE" ]; then
        if "$BIN_DIR/zenin_android_tools" menu-check "$PID" "$MODULE_BASE" 2> "$BIN_DIR/menu-probe.log"; then
            MENU_READY=1
            MENU_PROBE_OK=1
            echo 'Меню: native-флаг готовности ImGui установлен.'
        else
            PROBE_RESULT=$?
            if [ "$PROBE_RESULT" = 1 ]; then MENU_PROBE_OK=1; fi
        fi
    fi
    sleep 1
    OBSERVE=$((OBSERVE + 1))
done
echo 'Процесс игры оставался жив в течение окна наблюдения.'
if [ "$MENU_READY" = 0 ]; then
    if [ "$MENU_PROBE_OK" = 1 ]; then
        echo 'Меню: флаг готовности остался 0. Инициализация меню не завершилась.'
    else
        echo 'Меню: не удалось прочитать флаг готовности.'
        if [ -f "$BIN_DIR/menu-probe.log" ]; then cat "$BIN_DIR/menu-probe.log"; fi
    fi
fi
